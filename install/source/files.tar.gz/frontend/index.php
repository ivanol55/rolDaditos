<html>
	<head>
		<title>Tiradados de rol</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/style.css"> 
		</head>
	<body>
		<?php
		//inicializa variables en base al backend
		$ini_array = parse_ini_file("../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];
		?>
					<!--Personalización del nombre de la página-->
		<h2>Tiradados de rol de <?php echo $titulo; ?></h2>
		<h3>Tirador de dados múltiples automático</h3>
		<br>
		<form action="playerSelect.php">
			<!--Formulario de selección de personaje-->
			Jugador con el que registrar muertes: <select name="jugador">
				<?php
				//Listado de personajes posibles en la DB
				$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
				$conn = pg_pconnect($conn_string);
				$query = "SELECT personaje, campaignPersonaje FROM personajes";
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
					echo "<option value=\"" . $row[0] . "\">". $row[0] . " - " . $row[1] . "</option>";
					}
				?>
			</select>
			<br><br>
			<input type="submit" value="Establecer personaje">
		</form>
		<br><br><br><br>
		<!--Formularios de creación de personajes y campañas-->
		<h2>Si no tienes personaje/campaña</h2>
		<div class="grid-container">
			<div class="grid-item">
				<h3>Crear campaña si no existe</h3>
				<!--Formulario para crear una campaña donde luego añadir personajes-->
				<form action="creador/crearCampaign.php">
					Campaña a crear: <input type="text" name="campaign"><br><br>
					<input type="submit" value="Crear campaña">
				</form>
			</div>
			<div class="grid-item">
				<h3>Crear personaje para una campaña</h3>
				<!--Formulario para crear un personaje en una campaña específica-->
				<form action="creador/crearPersonaje.php">
					Nombre del personaje: <input type="text" name="personaje"><br><br>
					Campaña a la que pertenece: <select name="campaign">
						<?php
						//Crea listado de opciones de la DB
						$query = "SELECT campaign FROM campaigns";
						$result = pg_query($conn, $query);
						while ($row = pg_fetch_row($result)) {
							echo "<option value=\"" . $row[0] . "\">". $row[0] . "</option>";
							}
					?>
					</select>
					<br><br>
					<input type="submit" value="Crear personaje">		
				</form>
			</div>
		</div>
	</body>
</html>
