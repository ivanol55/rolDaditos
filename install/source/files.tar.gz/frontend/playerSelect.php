<html>
	<head>
		<title>Jugador establecido</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/style.css"> 
		<meta http-equiv="refresh" content="3;url=tiradados.php" />
	</head>
	<body>
		<h2>Jugador establecido</h2>
		<h3>Redirigiendo al tiradados</h3>
		<?php
		//Guarda el personaje elegido en una variable de sesión compartida
		session_start();
		$_SESSION["jugador"] = $_GET["jugador"];
		?>
	</body>
</html>
