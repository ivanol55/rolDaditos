<html>
	<head>
		<title>Resultados</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css">
	</head>
	<body>
		<h2>Resultados</h2>
		<br>
		<table style="width:30%" align="center">
			<tr><th>Dado</th><th>Resultado</th></tr>
			<?php
			//Inicializa las variables en base al archivo de backend
			session_start();
			$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
			$titulo = $ini_array["customization"]["name"];
			$dbUser = $ini_array["dbAccess"]["user"];
			$dbPass = $ini_array["dbAccess"]["password"];
			$dbDatabase = $ini_array["dbAccess"]["database"];
			$dbHost = $ini_array["dbAccess"]["host"];
			$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
			$conn = pg_pconnect($conn_string);
			//Por cada entrada de dados que ha recibido genera un numero aleatorio entre 1 y el numero de caras máximo de ese dado, lo muestra y lo inserta en la BD.
			foreach (range(1, $_GET['nDados']) as $number) {
				echo "<tr>";
					echo "<td>Dado d" . $_GET['caras' . $number] . "</td>";
					//Se guarda ese número en la variable resultado
					$resultado = rand(1, $_GET['caras' . $number]);
					echo "<td>" . $resultado  . "</td>";
				echo "</tr>";
				//Se inserta la tirada en la base de datos con el resultado recibido
				$query = "INSERT INTO tiradas (fechahora, personaje, dadotirado, nresultante, sesion) VALUES ". "('" . date("Y-m-d H:i:s") . "', '" . $_SESSION["jugador"] . "', '" . $_GET['caras' . $number] . "', '" . $resultado . "', " . $_SESSION["sesion"] . ")";
				pg_query($conn, $query);
				}
			?>
		</table>
		<br>
		<!--Volver al inicio del tiradados tras ver los resultados-->
		<form action="../tiradados.php">
			<input type="submit" value="Volver al inicio">
		</form> 
	</body>
</html>


