<html>
	<head>
		<title>Tabla de dados a pedir</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css"> 
	</head>
	<body>
		<h2>Caras de cada dado</h2>
		<!--Formulario para elegir las caras de cada dado-->
		<form action="resultados.php">
			<?php
			//Guarda la sesión a insertar en una variable de sesión de PHP
			session_start();
			$_SESSION["sesion"] = $_GET["sesion"];
			//Por cada número entre 1 y el recibido por el formulario, genera una entrada de datos donde poner un número de caras
			foreach (range(1, $_GET['nDados']) as $number) {
				echo "Dado ". $number . " ";
				echo "<input type=\"number\" name=\"caras" . $number . "\"><br><br>";
				}
			echo "<input style=\"visibility:hidden;\"type=\"text\" name=\"nDados\" value=\"". $_GET['nDados'] ."\"><br>";
			?>
			<!--Ir a ver los resultados de los dados-->
			<input type="submit" value="Ver resultados">
		</form>
	</body>
</html>
