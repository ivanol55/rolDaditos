<html>
	<head>
	<?php
		//Establece variables para usar en base a la información del backend
		session_start();
		$ini_array = parse_ini_file("../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];
		
		//Devuelve el ultimo número de sesión jugada por el personaje
		$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
		$conn = pg_pconnect($conn_string);
		$query = "SELECT sesion FROM tiradas WHERE personaje LIKE '" . $_SESSION["jugador"] . "' ORDER BY id DESC LIMIT 1";
		$result = pg_query($conn, $query);
		while ($row = pg_fetch_row($result)) {
			$sesion = $row[0];
			}

		//Si el personaje es nuevo, para evitar errores, establecemos la sesión a 1 inicialmente
		if (!isset($sesion)) {
			$sesion = 1;
			}
		?>
					<!--Personalización de la web-->
		<title>Tiradados de <?php echo $titulo; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/style.css"> 
		<meta http-equiv="refresh" content="120" />
	</head>
	<body>
		<h2>RolDaditos</h2>
		<h3>Tirador de dados múltiples automático</h3>
		<!--Muestra el jugador actual y la sesión jugada por última vez-->
		<h4><?php echo $_SESSION["jugador"] . " - última sesión registrada: " . $sesion; ?></h4>
		<!--Formulario para elegir el número de dados a tirar-->
		<form action="tirar/formvalores.php">
						<!--Devuelve por defecto la última sesión jugada-->
			Sesión de hoy: <input type="number" name="sesion" value= <?php echo "\"" . $sesion . "\""?>><br><br>
			<!--Pide el número de dados a tirar-->
			Numero de dados<br>
			<input type="number" name="nDados" value="1">
			<br><br>
			<input type="submit" value="tabla de dados">
		</form> 
		<br><br>
		<!--Lleva al log de tiradas-->
		<form action="log/log.php">
			<input type="submit" value="log de resultados">
		</form>
		<!--Lleva a los stats de cada personaje-->
		<form action="stats/stats.php">
			<input type="submit" value="stats de dados">
		</form> 
		<?php
			//Devuelve la última tirada hecha en la DB
			$query = "SELECT personaje, fechahora, dadotirado, nresultante FROM tiradas ORDER BY id DESC LIMIT 1";
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				echo $row[0] . " el " . $row[1] . "<br>ha tirado un" . $row[2] . "<br>Sacando un " . $row[3] . ".";
				}
			?>
		<br><br>
		<!--Lleva al selector de sesión, mostrará los stats de la sesión elegida-->
		<form action="statstotales/interPartida.php">
			<input type="submit" value="Stats por partida">
		</form>
		<!--Abre en otra pestaña una web limpia autorefreshing con el último dado tirado-->
		<form action="streamerbutton/stream.php">
			<input type="submit" value="Ultimo dado autoupdating" formtarget="_blank">
		</form>
	</body>
</html>
