<html>
	<head>
		<title>Resultados</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css">
	</head>
	<body>
		<h2>Log de tiradas</h2>
		<?php
		//Inicializa variables en base al archivo de backend
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];

		//Devuelve todas las rows de tiradas ordenando por id de mas nueva a mas antigua
		$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
		$conn = pg_pconnect($conn_string);
		$query = "SELECT * FROM tiradas ORDER BY id DESC;";
		$result = pg_query($conn, $query);
		
		//Muestra una tabla con todas las entradas recibidas
		echo "<table>";
			echo "<tr><td>id</td><td>Fecha y hora</td><td>sesión</td><td>Dado tirado</td><td>Resultado</td><td>Partida</td></tr>";
		while ($row = pg_fetch_row($result)) {
			echo "<tr>";
				echo "<td>" . $row[0] .  "</td><td>" . $row[1] .  "</td><td>" . $row[2] .  "</td><td>" . $row[3] .  "</td><td>" . $row[4] .  "</td><td>" . $row[5] .  "</td>";
			echo "</tr>";
			}
		echo "</table>";
		?>
		<!--Volver al tiradados-->
		<form action="../tiradados.php">
			<input type="submit" value="Volver al inicio">
		</form> 
	</body>
</html>


