<html>
	<head>
		<title>Tiradados de rol</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css">
		<meta http-equiv="refresh" content="2;url=../index.php" /> 
	</head>
	<body>
		<?php
		//INicializa variables en base al archivo de backend
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];
		?>
		<h2>Campaña creada!</h2>
		<h3>Ya puedes elegir esta campaña para crear personajes!</h3>
		<?php
		//Inserta la campaña recibida por GET de formulario a la tabla Campaigns de la DB
		$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
		$conn = pg_pconnect($conn_string);
		$query = "INSERT INTO campaigns(campaign) VALUES ('" . $_GET["campaign"]. "')";
		$result = pg_query($conn, $query);
		?>
	</body>
</html>
