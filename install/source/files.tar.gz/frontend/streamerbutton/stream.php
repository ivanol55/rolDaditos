<html>
	<head>
		<title>Ultimo dado refreshing</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css"> 
		<!--Recarga la página cada 3 segundos para actualizar el dado-->
		<meta http-equiv="refresh" content="3" />
	</head>
	<body>
		<?php
		//Inicializa variables en base al documento de backend
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];

		//Devuelve el último dado lanzado y lo muestra por pantalla
		$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
		$conn = pg_pconnect($conn_string);
		$query = "SELECT personaje, fechahora, dadotirado, nresultante FROM tiradas ORDER BY id DESC LIMIT 1";
		$result = pg_query($conn, $query);
		while ($row = pg_fetch_row($result)) {
			echo $row[0] . " el " . $row[1] . "<br>ha tirado un d" . $row[2] . "<br>Sacando un " . $row[3] . ".";
			}	
		?>
	</body>
</html>
