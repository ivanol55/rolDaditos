<html>
	<head>
		<title>Selecciona sesión y partida</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css"> 
		<meta http-equiv="refresh" content="120;url=tiradados.php" />
	</head>
	<body>
		<h2>Stats por sesión y partida</h2>
		<h3>Elige de qué sesión quieres ver los datos</h3>
		<?php
		//Declara variables en base al archivo de backend
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];
		?>
		<!--Listado de todas las posibles sesiones a revisar para enviar una a la siguiente página-->
		<form action="partidas.php">
			<select id="partida" name="partida">
			<?php
			//Por cada entrada de sesión de cada partida genera una entrada option
			$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
			$conn = pg_pconnect($conn_string);
			$query = "SELECT DISTINCT sesion, campaignpersonaje FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje ORDER BY campaignpersonaje, sesion DESC";
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				//Se encadenan ambos datos necesarios con un | para separarlos luego
				echo "<option value=\"" . $row[0] . "|" . $row[1] . "\">" . $row[1] . " - sesión " . $row[0] . "</option>";
				}
		?> 
			</select>
			<br><br>
			<input type="submit" value="Stats de partida">
		</form> 
		<br><br>
		<!--Volver atrás al inicio de la web-->
		<form action="../tiradados.php">
			<input type="submit" value="Volver al inicio">
		</form> 
	</body>
</html>
