<html>
	<head>
		<?php
		//Declara variables en base al archivo de backend
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];
		//Convierte los datos recibidos de sesión y partida en un array con el divisor y los separa en variables
		$datos = explode("|",$_GET["partida"]);
		$sesion = $datos[0];
		$campaign = $datos[1];
		$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
		$conn = pg_pconnect($conn_string);
		?>
		<title>Stats por sesión</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css"> 
	</head>
	<body>
		<!--Muestra la sesión y partida de la que se están viendo datos-->
		<h2>Información de la sesión <?php echo $sesion ?> de la campaña <?php echo $campaign ?></h2>
		<!--Botón para volver al inicio-->
		<form action="../tiradados.php" style="text-align:center;">
			<input type="submit" value="Volver al inicio">
		</form>
		<!--Contenedor de tablas con CSS Grid-->
		<div class="grid-container">
			<table class="grid-item">
				<thead align="center">
					<tr><td colspan="2">Tiradas por hora de juego</td></tr>
				</thead>
				<tr><td>Hora</td><td>Tiradas</td></tr>
				<?php
				//Devuelve las tiradas que se han hecho cada hora y lo muestra en una tabla
				$query = "SELECT hora, AVG(t.contado) AS tphora FROM (SELECT date_part('hour', fechahora) AS hora, COUNT(*) AS contado FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignPersonaje LIKE '" . $campaign . "' GROUP BY date_part('hour', fechahora)) t GROUP BY hora";
				$result = pg_query($conn, $query);
				while ($row = pg_fetch_row($result)) {
			        echo "<tr><td>" . $row[0] . ":00" . "</td>";
				echo "<td>" . intval($row[1]) . "</td></tr>";
					}
				?>
			</table>
			<table class="grid-item">
				<thead align="center">
					<tr><td colspan="2">Media de dados por hora</td></tr>
				</thead>
					<tr><td>Media</td></tr>
						<?php
						//Muestra la media de datos lanzados por hora en la sesión especificada
						$query = "SELECT AVG(contado) as media FROM (SELECT COUNT(*) contado FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignpersonaje LIKE '" . $campaign . "' GROUP BY DATE_PART('HOUR', fechahora)) t";
						$result = pg_query($conn, $query);
						while($row = pg_fetch_row($result)) {
							echo "<tr>";
								echo "<td>" . floatval($row[0]) . "</td>";
							echo "</tr>";
							}
						?>
			</table>
			<table class="grid-item">
				<thead align="center">
					<tr><td colspan="2">Media de resultados de la sesión</td></tr>
				</thead>
				<tr><td>Media</td></tr>
				<?php
				//Muestra la media de resultados de los dados de la sesión
				$query = "SELECT ROUND(AVG(nresultante), 2) AS media FROM tiradas JOIN PERSONAJES ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . "AND campaignpersonaje LIKE '" . $campaign . "'";
				$result = pg_query($conn, $query);
				while($row = pg_fetch_row($result)) {
				        echo "<tr>";
						echo "<td>" . floatval($row[0]) ."</td>";
					echo "</tr>";
					}
				?>
			</table>
			<table class="grid-item">
				<thead align="center">
					<tr><td colspan="3">Mejores tiradas de la partida</td></tr>
				</thead>
				<tr><td>Jugador</td><td>Hora</td><td>Tirada</td></tr>
				<?php
				//Muestra las mejores tiradas de la sesión seleccionada
				$query = "SELECT tiradas.personaje, fechahora, nresultante FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignpersonaje LIKE '" . $campaign . "' AND nresultante = (SELECT MAX(nresultante) FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignpersonaje LIKE '" . $campaign . "')";
				$result = pg_query($conn, $query);
				while($row = pg_fetch_row($result)) {
				        echo "<tr>";
						echo "<td>" . $row[0] ."</td>";
						echo "<td>" . $row[1] . "</td>";
						echo "<td>" . $row[2] . "</td>";
					echo "</tr>";
					}
				?>
			</table>
			<table class="grid-item">
				<thead align="center">
					<tr>
						<td colspan="3">Peores tiradas de la partida</td>
					</tr>
				</thead>
				<tr><td>Jugador</td><td>Hora</td><td>Tirada</td></tr>
				<?php
				//Muestra las peores tiradas de la sesión seleccionada
				$query = "SELECT tiradas.personaje, fechahora, nresultante FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignpersonaje LIKE '" . $campaign . "' AND nresultante = (SELECT MIN(nresultante) FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignpersonaje LIKE '" . $campaign . "')";
				$result = pg_query($conn, $query);
				while($row = pg_fetch_row($result)) {
				        echo "<tr>";
						echo "<td>" . $row[0] ."</td>";
						echo "<td>" . $row[1] . "</td>";
						echo "<td>" . $row[2] . "</td>";
					echo "</tr>";
					}
				?>
			</table>
			<table class="grid-item">
				<thead align="center">
					<tr><td colspan="3">Mayor cantidad de dados tirados</td></tr>
				</thead>
				<tr><td>Jugador</td><td>dados</td></tr>
				<?php
				//Muestra quién ha tirado más dados en esta sesión
				$query = "SELECT tiradas.personaje, COUNT(*) as cuantosDados FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = ". $sesion . " AND campaignpersonaje LIKE '" . $campaign . "' GROUP BY tiradas.personaje HAVING COUNT(*) = (SELECT COUNT(*) FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignpersonaje LIKE '" . $campaign . "' GROUP BY tiradas.personaje ORDER BY COUNT(*) DESC LIMIT 1) ORDER BY COUNT(*) DESC";
				$result = pg_query($conn, $query);
				while($row = pg_fetch_row($result)) {
				        echo "<tr>";
						echo "<td>" . $row[0] . "</td>";
						echo "<td>" . $row[1] . "</td>";
					echo "</tr>";
					}
				?>
			</table>
			<table class="grid-item">
				<thead align="center">
					<tr>
						<td colspan="3">Menor cantidad de dados tirados</td>
					</tr>
				</thead>
				<tr><td>Jugador</td><td>dados</td></tr>
				<?php
				//Muestra quién ha tirado menos dados en esta sesión
				$query = "SELECT tiradas.personaje, COUNT(*) as cuantosDados FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = ". $sesion . " AND campaignpersonaje LIKE '" . $campaign . "' GROUP BY tiradas.personaje HAVING COUNT(*) = (SELECT COUNT(*) FROM tiradas JOIN personajes ON tiradas.personaje = personajes.personaje WHERE sesion = " . $sesion . " AND campaignpersonaje LIKE '" . $campaign . "' GROUP BY tiradas.personaje ORDER BY COUNT(*) ASC LIMIT 1) ORDER BY COUNT(*) DESC";
				$result = pg_query($conn, $query);
				while($row = pg_fetch_row($result)) {
				        echo "<tr>";
						echo "<td>" . $row[0] ."</td>";
						echo "<td>" . $row[1] . "</td>";
					echo "</tr>";
					}
				?>
			</table>
		</div>
	</body>
</html>
