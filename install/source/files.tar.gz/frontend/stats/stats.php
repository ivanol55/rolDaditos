<html>
	<head>
		<title>Stats de personajes</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="../css/style.css"> 
		<meta http-equiv="refresh" content="120;url=stats.php" />
		<?php 
		//Inicializa variables en base al archivo de backend
		$ini_array = parse_ini_file("../../backend/creds/.my.cnf", true);
		$titulo = $ini_array["customization"]["name"];
		$dbUser = $ini_array["dbAccess"]["user"];
		$dbPass = $ini_array["dbAccess"]["password"];
		$dbDatabase = $ini_array["dbAccess"]["database"];
		$dbHost = $ini_array["dbAccess"]["host"];
		?>
	</head>
	<body>
		<h2>Stats por personaje</h2>
		<h3>Stats</h3>
		<!--Muestra una tabla para cada usuario con sus dados tirados totales y su media de resultados-->
		<div class="grid-container">
			<?php
			//Devuelve el nombre de todos los personajes de la DB y los pone en un array
			$conn_string = "host=" . $dbHost . " port=5432 dbname=" . $dbDatabase . " user=" . $dbUser . " password=" . $dbPass;
			$conn = pg_pconnect($conn_string);
			$query = "SELECT personaje, campaignpersonaje FROM personajes";
			$players = array();
			$result = pg_query($conn, $query);
			while ($row = pg_fetch_row($result)) {
				$players[] = array($row[0],$row[1]);
				}
			//Por cada objeto del array genera una tabla con una query de su total de tiradas y su media de resultados
			foreach ($players as $player) {
				echo "<table class=\"grid-item\">";
					echo "<tr>";
						echo "<td>Personaje</td>";
						echo "<td>" . $player[0] . " - " . $player[1] . "</td>";
					echo "</tr>";
					echo "<tr>";
						echo "<td>Tiradas totales</td>";
						echo "<td>";
						$querytotal = "SELECT COUNT(*) AS total FROM tiradas WHERE personaje LIKE '" . $player[0] . "'";
						$result = pg_query($conn, $querytotal);
						while ($rownum = pg_fetch_row($result)) {
							echo $rownum[0];
						}
						echo "</td>";
					echo "</tr>";
					echo "<tr>";
						echo "<td>Media de resultados</td>";
						echo "<td>";
						$querymedia = "SELECT AVG(nresultante) as total FROM tiradas WHERE personaje LIKE '" . $player[0] . "'";
						$result = pg_query($conn, $querymedia);
						while ($rowavg = pg_fetch_row($result)) {
							echo round($rowavg[0], 2);
						}
						echo "</td>";
					echo "</tr>";
				echo "</table>";
				}
			?>
		</div>
		<br><br>
		<!--Botón para volver al principio de la web-->
		<form action="../tiradados.php">
			Volver al inicio<br>
			<br>
			<input type="submit" value="Tiradados">
		</form> 
	</body>
</html>
